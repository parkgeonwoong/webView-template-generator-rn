import { NavigationProp, useNavigation } from '@react-navigation/native';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StatusBar, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import WebView from 'react-native-webview';

import { ErrorView } from '../components/ErrorView';
import { LoadingView } from '../components/LoadingView';
import { ALLOW_HOSTS, BASE_URL, injected, START_PATH } from '../webview/constants';
import { makeOnMessage as _makeOnMessage } from '../webview/handlers/onMessage';
import { makeOnNavStateChange } from '../webview/handlers/onNavStateChange';
import { makeOnShouldStart } from '../webview/handlers/onShouldStart';
import {
  mapWebViewError,
  WebErrorCategory,
} from '../webview/utils/mapWebViewError';

import { openSettings } from 'react-native-permissions';

export default function Test(): React.ReactElement {
  const ref = useRef<WebView>(null); // 웹뷰 참조
  const hardReload = () => ref.current?.reload(); // 웹뷰 강제 리로드
  const [cacheKey, setCacheKey] = useState(0); // 캐시 키
  const [loading, setLoading] = useState(true); // 로딩 상태

  const [errorMsg, setErrorMsg] = useState<string | null>(null); // 에러 메시지
  const [errorCategory, setErrorCategory] = useState<
    WebErrorCategory | undefined
  >(undefined); // 에러 카테고리

  const [initialURL, setInitialURL] = useState<string | null>(null); // 초기 URL

  const canGoBackRef = useRef(false); // 뒤로가기 가능 여부

  const navigation: NavigationProp<any> = useNavigation();

  const onShouldStart = useCallback(makeOnShouldStart(ALLOW_HOSTS), []); // 웹뷰 로딩 시 호출
  const onNavStateChange = useCallback(makeOnNavStateChange(canGoBackRef), []); // 웹뷰 네비게이션 상태 변경 시 호출

  const isDebugMode = __DEV__;

  /* 에러 처리 */
  const handleRetry = () => {
    setErrorMsg(null);
    setErrorCategory(undefined);
    setLoading(true);
    setCacheKey(cacheKey => cacheKey + 1);
  };

  /* 메시지 처리 : 웹뷰로부터 받은 메시지를 처리하는 함수 */
  const onMessage = useCallback(
    _makeOnMessage({ ref, navigation, hardReload, setCacheKey }),
    [],
  );

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: 'rgb(255,255,255)',
      }}
    >
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle={'dark-content'} />
        <WebView
          ref={ref}
          key={cacheKey} // 키가 바뀌면 리마운트
          // pullToRefreshEnabled // 웹 프론트에서 새로고침 이미 구현되어 있어서 사용 X
          source={{ uri:  }}
          onContentProcessDidTerminate={() => ref.current?.reload()} // IOS 컨텐츠 프로세스 종료 시 리로드
          onRenderProcessGone={event => {
            const { didCrash } = event.nativeEvent;
            // Android 렌더 프로세스 종료 시 리로드
            if (didCrash) {
              setCacheKey(key => key + 1);
            }
          }}
          javaScriptEnabled
          domStorageEnabled
          sharedCookiesEnabled
          onLoadProgress={e => {
            e.nativeEvent.progress >= 1 && setLoading(false);
          }}
          onLoadStart={() => {
            setLoading(true);
            setErrorMsg(null);
          }}
          onLoad={() => setLoading(false)}
          onLoadEnd={() => setLoading(false)}
          onError={syntheticEvent => {
            // description과 (있다면) statusCode로 분류
            const { nativeEvent } = syntheticEvent;
            const { category } = mapWebViewError(
              nativeEvent?.description,
              (nativeEvent as any)?.statusCode,
            );
            setErrorCategory(category);
            setErrorMsg(nativeEvent?.description || null);
            setLoading(false);
          }}
          onNavigationStateChange={onNavStateChange}
          injectedJavaScriptBeforeContentLoaded={injected}
          onMessage={onMessage}
          onShouldStartLoadWithRequest={onShouldStart}
          allowsBackForwardNavigationGestures
          javaScriptCanOpenWindowsAutomatically={true}
          setSupportMultipleWindows={true}
          originWhitelist={['*']}
          onOpenWindow={() => {}}
          // TODO: IOS 디버깅 QA도 가능하도록 설정
          webviewDebuggingEnabled={isDebugMode ? true : false}
        />

        {/* 로딩 오버레이 */}
        {loading && !errorMsg && (
          <View style={styles.overlay}>
            <LoadingView />
          </View>
        )}

        {/* 에러 오버레이 (웹뷰를 가려서 하단이 비치지 않음) */}
        {!!errorMsg && (
          <View style={styles.overlay}>
            <ErrorView
              message={errorMsg}
              category={errorCategory}
              onRetry={handleRetry}
              onOpenSettings={() => {
                // 네트워크 설정 등으로 보낼 수 있으면 여기서 Linking.openSettings() 등 호출
                openSettings();
              }}
            />
          </View>
        )} 
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.1)', // 필요 시 투명도 조절
  },
});
