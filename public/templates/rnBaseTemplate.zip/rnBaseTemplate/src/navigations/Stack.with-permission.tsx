import React, { useEffect, useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import Tmp from '../screens/Tmp';
import WebShell from '../screens/WebShell';
import PermissionGuide from '../screens/PermissionGuide';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { PERMISSION_GUIDE_SHOWN_KEY } from '../config/webview';

const Stack = createStackNavigator();

const StackNavigation = () => {
  const [isReady, setIsReady] = useState(false);
  const [showPermissionGuide, setShowPermissionGuide] = useState(false);

  useEffect(() => {
    const init = async () => {
      try {
        const hasShownGuide = await AsyncStorage.getItem(PERMISSION_GUIDE_SHOWN_KEY);
        // 아직 한 번도 안 봤으면 권한 안내 화면부터
        setShowPermissionGuide(hasShownGuide === null);
      } catch (error) {
        // 에러 나면 그냥 바로 WebShell 로
        setShowPermissionGuide(false);
      } finally {
        setIsReady(true);
      }
    };

    init();
  }, []);

  if (!isReady) {
    return null; // 필요하면 스플래시/로딩 화면 넣어도 됨
  }

  const initialRouteName = showPermissionGuide ? 'PermissionGuide' : 'WebShell';

  return (
    <Stack.Navigator initialRouteName={initialRouteName}>
      {showPermissionGuide && (
        <Stack.Screen name="PermissionGuide" component={PermissionGuide} options={{ headerShown: false }} />
      )}

      <Stack.Screen name="WebShell" component={WebShell} options={{ headerShown: false }} />

      {/* TODO: 임시 화면 */}
      <Stack.Screen name="Tmp" component={Tmp} options={{ headerBackTitle: '뒤로가기' }} />
    </Stack.Navigator>
  );
};

export default StackNavigation;
