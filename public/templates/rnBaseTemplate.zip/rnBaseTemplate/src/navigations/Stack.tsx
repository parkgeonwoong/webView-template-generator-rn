import { createStackNavigator } from '@react-navigation/stack';

import Tmp from '../screens/Tmp';
import WebShell from '../screens/WebShell';

const Stack = createStackNavigator();

const StackNavigation = () => {
  return (
    <Stack.Navigator initialRouteName="WebShell">
      <Stack.Screen name="WebShell" component={WebShell} options={{ headerShown: false }} />

      {/* TODO: 임시 화면 */}
      <Stack.Screen name="Tmp" component={Tmp} options={{ headerBackTitle: '뒤로가기' }} />
    </Stack.Navigator>
  );
};

export default StackNavigation;
