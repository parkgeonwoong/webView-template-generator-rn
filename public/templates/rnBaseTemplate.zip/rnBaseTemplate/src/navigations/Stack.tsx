import { createStackNavigator } from '@react-navigation/stack';
import Tmp from '../screens/Tmp';
import App2 from '../screens/App2';
import { Text, TouchableOpacity } from 'react-native';
import { NavigationProp, useNavigation } from '@react-navigation/native';
import WebShell from './WebShell';

const Stack = createStackNavigator();

const StackNavigation = () => {
  const navigation = useNavigation<NavigationProp<any>>();

  return (
    <Stack.Navigator initialRouteName="App2">
      <Stack.Screen
        name="App2"
        component={App2}
        /* Tmp 이동 버튼 추가 */
        options={{
          headerRight: () => (
            <TouchableOpacity onPress={() => navigation.navigate('WebShell')}>
              <Text>WebShell</Text>
            </TouchableOpacity>
          ),
        }}
      />
      <Stack.Screen name="WebShell" component={WebShell} />

      <Stack.Screen
        name="Tmp"
        component={Tmp}
        options={{ headerBackTitle: '뒤로가기' }} // "뒤로가기" 라고 설정을 하지 않으면 대신 "< WebShell " 이라고 나옵니다.
      />
    </Stack.Navigator>
  );
};

export default StackNavigation;
