import React, { useCallback, useRef, useState } from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import WebView from 'react-native-webview';

import { LoadingView } from '../components/LoadingView';
import { ErrorView } from '../components/ErrorView';
import { mapWebViewError, WebErrorCategory } from '../utils/mapWebViewError';
import { makeOnNavStateChange } from '../utils/onNavStateChange';
import { makeOnShouldStart } from '../utils/onShouldStart';
import { makeOnMessage } from '../handler/onMessage';

import { ALLOW_HOSTS, INJECTED_JS_BRIDGE, WEBVIEW_DEBUGGING_ENABLED, WEBVIEW_URI } from '../config/webview';

export default function WebShell() {
  const ref = useRef<WebView>(null); // 웹뷰 ref
  const [cacheKey, setCacheKey] = useState(0); // 리마운트용 키 (크래시 대응 등)

  const [loading, setLoading] = useState(true); // 로딩 상태
  const [errorMsg, setErrorMsg] = useState<string | null>(null); // 에러 메시지
  const [errorCategory, setErrorCategory] = useState<WebErrorCategory | undefined>(undefined); // 에러 카테고리

  const canGoBackRef = useRef(false); // 뒤로가기 가능 여부

  // (옵션) 외부에서 강제 리로드 하고 싶을 때 사용
  const hardReload = () => {
    ref.current?.reload();
  };

  // ========================
  // 1. 에러 / 로딩 처리
  // ========================
  const handleRetry = () => {
    setErrorMsg(null);
    setErrorCategory(undefined);
    setLoading(true);
    // 필요 시 완전 리마운트 하고 싶으면 cacheKey 도 증가
    // setCacheKey(key => key + 1);
  };

  const handleError = useCallback((syntheticEvent: any) => {
    const { nativeEvent } = syntheticEvent;
    const { category } = mapWebViewError(nativeEvent?.description, (nativeEvent as any)?.statusCode);
    setErrorCategory(category);
    setErrorMsg(nativeEvent?.description || null);
    setLoading(false);
  }, []);

  // ========================
  // 2. 네비게이션 콜백 (확장 포인트)
  // ========================
  const onShouldStart = useCallback(makeOnShouldStart(ALLOW_HOSTS), []);
  const onNavStateChange = useCallback(makeOnNavStateChange(canGoBackRef), []);

  /* 브릿지 onMessage 콜백 */
  const onMessage = useCallback(makeOnMessage({ ref: ref as React.RefObject<WebView>, setCacheKey }), []);

  return (
    <View style={[styles.container, { backgroundColor: 'rgb(255,255,255)' }]}>
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle={'dark-content'} />
        <WebView
          ref={ref}
          key={cacheKey} // 키가 바뀌면 리마운트
          source={{ uri: WEBVIEW_URI }}
          style={{ flex: 1 }}
          // === WebView 기본 옵션 / 크래시 대응 ===
          onContentProcessDidTerminate={() => ref.current?.reload()} // IOS 컨텐츠 프로세스 종료 시 리로드
          onRenderProcessGone={event => {
            const { didCrash } = event.nativeEvent;
            // Android 렌더 프로세스 종료 시 리로드
            if (didCrash) {
              setCacheKey(key => key + 1);
            }
          }}
          javaScriptEnabled
          domStorageEnabled
          sharedCookiesEnabled
          // === 로딩 상태 ===
          onLoadProgress={e => {
            e.nativeEvent.progress >= 1 && setLoading(false);
          }}
          onLoadStart={() => {
            setLoading(true);
            setErrorMsg(null);
          }}
          onLoad={() => setLoading(false)}
          onLoadEnd={() => setLoading(false)}
          onError={handleError}
          injectedJavaScriptBeforeContentLoaded={INJECTED_JS_BRIDGE} // 브릿지 코드 주입
          // === 네비게이션 제어 ===
          onShouldStartLoadWithRequest={onShouldStart}
          onNavigationStateChange={onNavStateChange}
          onMessage={onMessage}
          allowsBackForwardNavigationGestures
          javaScriptCanOpenWindowsAutomatically={true}
          setSupportMultipleWindows={true}
          originWhitelist={['*']}
          onOpenWindow={e => {
            const newTargetUrl = e?.nativeEvent?.targetUrl ?? '';
            // TODO: 결제/소셜로그인 팝업 등은 여기에서 분기
          }}
          webviewDebuggingEnabled={WEBVIEW_DEBUGGING_ENABLED === 'true'}
        />

        {/* 로딩 오버레이 */}
        {loading && !errorMsg && (
          <View style={styles.overlay}>
            <LoadingView />
          </View>
        )}

        {/* 에러 오버레이 */}
        {!!errorMsg && (
          <View style={styles.overlay}>
            <ErrorView message={errorMsg} category={errorCategory} onRetry={handleRetry} />
          </View>
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.1)', // 필요 시 투명도 조절
  },
});
