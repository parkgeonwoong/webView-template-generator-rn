import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, StatusBar } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { PERMISSION_GUIDE_SHOWN_KEY } from '../config/webview';

interface Props {
  navigation: any;
}

/**
 * @description : 앱권한안내 화면
 * - 권한 안내 화면 표시
 * - 권한 확인 버튼 클릭 시 웹 화면으로 이동
 */
const PermissionGuide: React.FC<Props> = ({ navigation }) => {
  const handleConfirm = async () => {
    try {
      // 권한 안내를 봤다는 플래그 저장
      await AsyncStorage.setItem(PERMISSION_GUIDE_SHOWN_KEY, 'true');

      // TODO: 향후 필수 권한들 경우 권한 요청 후 화면 이동
      // 예시) 생체인증 await authenticateBiometric();
      // 예시) 카메라, 사진 보관함 권한 요청 await requestPermissions(['camera', 'photos']);

      // 메인 화면으로 이동
      navigation.replace('WebShell');
    } catch (error) {}
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle={'dark-content'} />
      {/* 앱 접근 권한 안내 화면 */}
      <Text style={styles.title}>앱 접근 권한 안내</Text>
      <Text style={styles.subtitle}>서비스 사용을 위해 다음 권한의 허용이 필요합니다.</Text>

      {/* 권한 항목 */}
      <View style={styles.permissionItem}>
        <View style={styles.iconContainer}>
          {/* 카메라 아이콘 */}
          <Image
            source={require('../assets/icon_camera_line_achromatic.png')}
            style={styles.iconImage}
            resizeMode="contain"
          />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.permissionTitle}>카메라 접근 권한(선택)</Text>
          <Text style={styles.permissionDesc}>이미지 촬영을 위해 카메라를 사용합니다.</Text>
        </View>
      </View>

      <View style={styles.permissionItem}>
        <View style={styles.iconContainer}>
          {/* 폴더 아이콘 */}
          <Image
            source={require('../assets/icon_folder_line_achromatic.png')}
            style={styles.iconImage}
            resizeMode="contain"
          />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.permissionTitle}>사진 보관함 접근 권한(선택)</Text>
          <Text style={styles.permissionDesc}>이미지 등록을 위해 사진 보관함에 접근합니다.</Text>
        </View>
      </View>

      {/* TODO: 향후 추가될 권한 항목 */}

      {/* 공백 */}
      <View style={styles.spacer} />

      {/* 안내 메시지 */}
      <Text style={styles.notice}>
        *허용하지 않으셔도 앱 이용은 가능하나, 일부 서비스 이용에 제한이 있을 수 있습니다.
      </Text>

      {/* 확인 버튼 */}
      <TouchableOpacity style={styles.confirmButton} onPress={handleConfirm}>
        <Text style={styles.confirmButtonText}>확인</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 40,
    marginBottom: 20,
  },
  subtitle: {
    fontSize: 14,
    color: '#333',
    marginBottom: 40,
    lineHeight: 20,
  },
  permissionItem: {
    flexDirection: 'row',
    marginBottom: 30,
  },
  iconContainer: {
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  iconImage: {
    width: 24,
    height: 24,
  },
  textContainer: {
    flex: 1,
  },
  permissionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 8,
  },
  permissionDesc: {
    fontSize: 12,
    color: '#666',
    lineHeight: 20,
  },
  spacer: {
    flex: 1,
  },
  notice: {
    fontSize: 12,
    color: '#5d5e60',
    lineHeight: 18,
    marginBottom: 20,
  },
  confirmButton: {
    backgroundColor: '#007aff',
    height: 56,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  confirmButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default PermissionGuide;
