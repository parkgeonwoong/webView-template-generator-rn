import { StyleSheet, Text, View } from "react-native";

export default () => {
    return (
        <View style={[styles.container]}>
            <View style={[styles.textGroup]}>
                <Text> 여기는 임시 화면입니다. </Text>
                <Text> /src/screens/ </Text>
                <Text> 여기에 화면이 될 파일을 새로 만들고 </Text>
                <Text> /src/navigation/Stack.tsx </Text>
                <Text> 여기에 추가해 주세요 </Text>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    textGroup: {
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
});