// /src/webview/utils/isMainFrame.ts
import { Platform } from 'react-native';

// 요청이 메인 프레임에서 발생한 것인지 판별
export const isMainFrame = (req: any) => {
    // iOS 환경일 경우
    // if (Platform.OS === 'ios') {
    //     // mainDocumentURL을 문자열로 변환, 값이 없으면 빈 문자열 사용
    //     const main = req?.mainDocumentURL?.toString?.() || '';
    //     // main이 비어 있거나 요청 URL이 mainDocumentURL과 같으면 메인 프레임으로 판단
    //     return !main || req.url === main;
    // }
    return true; // Android는 기본적으로 모든 요청을 메인프레임에서 발생된 요청으로 인식함
};