// /src/webview/utils/mapWebViewError.ts
// 에러 카테고리 분류
export type WebErrorCategory =
    | "OFFLINE"
    | "DNS"
    | "SSL"
    | "TIMEOUT"
    | "CONNECTION_REFUSED"
    | "TOO_MANY_REDIRECTS"
    | "UNKNOWN_URL_SCHEME"
    | "HTTP_ERROR"
    | "BAD_URL"
    | "OTHER";

export interface MappedWebError {
    category: WebErrorCategory;
    // 워래 에러 메시지
    raw?: string;
}

export function mapWebViewError(description?: string, httpStatus?: number): MappedWebError {
    if (typeof httpStatus === "number" && httpStatus >= 400) {
        return { category: "HTTP_ERROR", raw: description };
    }

    if (!description) return { category: "OTHER", raw: description };
    const msg = description.toLowerCase();

    // ---- OFFLINE ----
    if (
        msg.includes("offline") ||
        msg.includes("internet disconnected") ||
        msg.includes("net::err_internet_disconnected")
    ) return { category: "OFFLINE", raw: description };

    // ---- DNS (도메인 없음) ----
    if (
        msg.includes("not resolved") ||
        msg.includes("host could not be found") ||
        msg.includes("a server with the specified hostname could not be found") ||
        msg.includes("net::err_name_not_resolved")
    ) return { category: "DNS", raw: description };

    // ---- SSL(인증오류) ----
    if (
        msg.includes("ssl") ||
        msg.includes("certificate") ||
        msg.includes("secure connection") ||
        msg.includes("net::err_cert") ||
        msg.includes("net::err_ssl")
    ) return { category: "SSL", raw: description };

    // ---- TIMEOUT(타임아웃) ----
    if (
        msg.includes("timed out") ||
        msg.includes("timeout") ||
        msg.includes("net::err_connection_timed_out")
    ) return { category: "TIMEOUT", raw: description };

    // ---- CONNECTION_REFUSED ----
    if (
        msg.includes("connection refused") ||
        msg.includes("net::err_connection_refused")
    ) return { category: "CONNECTION_REFUSED", raw: description };

    // ---- TOO_MANY_REDIRECTS ----
    if (
        msg.includes("too many redirects") ||
        msg.includes("net::err_too_many_redirects")
    ) return { category: "TOO_MANY_REDIRECTS", raw: description };

    // ---- UNKNOWN_URL_SCHEME ----
    if (
        msg.includes("unknown url scheme") ||
        msg.includes("net::err_unknown_url_scheme")
    ) return { category: "UNKNOWN_URL_SCHEME", raw: description };

    // ---- BAD_URL ----
    if (
        msg.includes("bad url") ||
        msg.includes("unsupported url") ||
        msg.includes("net::err_invalid_url")
    ) return { category: "BAD_URL", raw: description };

    return { category: "OTHER", raw: description };
}