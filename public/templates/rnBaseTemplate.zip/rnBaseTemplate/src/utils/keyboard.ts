import WebView from 'react-native-webview';

/**
 * @desc : 키보드 동작제어
 * - Webview 내부의 입력 필드에 키보드 보여주기/감추기
 */

/* 키보드 보여주기 */
export const showKeyboard = (ref: React.RefObject<WebView<{}> | null>, selector?: string) => {
  const defaultSelector = 'input:not([type="hidden"]):not([disabled]), textarea:not([disabled])';
  const targetSelector = selector || defaultSelector;

  const js = `
    (function() {
      const input = document.querySelector('${targetSelector}');
      if (input) {
        input.focus(); 
      }
    })();
  `;

  ref.current?.injectJavaScript(js);
};

/* 키보드 감추기 */
export const hideKeyboard = (ref: React.RefObject<WebView<{}> | null>) => {
  const js = `
    (function() {
        // 현재 포커스된 요소를 blur
        if (document.activeElement && document.activeElement.blur) {
          document.activeElement.blur();
        }
          
        // 추가적으로 모든 입력 필드의 포커스를 해제
        const inputs = document.querySelectorAll('input, textarea, [contenteditable="true"]');
        inputs.forEach(input => {
            if (input.blur) {
                input.blur();
            }
        });
        return true;
    })();
    `;

  ref.current?.injectJavaScript(js);
};
