import WebView from 'react-native-webview';

const CLEAR_JS = `
(function() {
    // 안전하게 함수 실행 (오류 발생 시 무시)
    function safe(fn) { try { return fn(); } catch(e) { return Promise.resolve(); } }

    // localStorage 데이터 삭제
    safe(() => { localStorage && localStorage.clear && localStorage.clear(); });
    // sessionStorage 데이터 삭제
    safe(() => { sessionStorage && sessionStorage.clear && sessionStorage.clear(); });

    // IndexedDB 데이터 삭제
    const deleteIndexedDB = (async () => {
        if (!('indexedDB' in window)) return; // IndexedDB 지원 여부 확인 크롬은 지원, iOS는 미지원 웹 표준은 아님
        const dbs = (indexedDB.databases ? await indexedDB.databases() : []); // 모든 DB 목록 가져오기
        if (Array.isArray(dbs)) {
            for (const db of dbs) {
                if (db && db.name) {
                    try { 
                        indexedDB.deleteDatabase(db.name); 
                    } catch(e) {

                    }
                }
            }
        }
    })();

    // Cache 저장소
    const deleteCaches = (async () => {
        if (!('caches' in window)) return; // 위랑 동일하게 캐시 지원확인 먼저 하고
        const names = await caches.keys(); // 키값 가져와서
        await Promise.all(names.map((name) => {
            caches.delete(name);
        })); // 키 순환하면서 캐시 지우기
    })();

    // 모든 삭제 작업 완료 후 화면단에 완료 메시지 전달
    Promise.all([deleteIndexedDB, deleteCaches]).then(() => {
        // 화면단에 완료 알림
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(
            JSON.stringify({ type:'WEBVIEW', event:'CACHE_CLEARED' })
        );
    });
})(); true; // 종료 후 true 반환
`;

// 웹뷰 캐시 및 저장 데이터 삭제 함수
export async function clearSiteData(ref: React.RefObject<WebView<{}> | null>) {
  // 웹뷰에 CLEAR_JS 코드 삽입하여 실행 브라우저 소스코드상 제일 하단에 배치됨
  ref.current?.injectJavaScript(CLEAR_JS);
  // 쿠키는 별도의 처리 필요
}
