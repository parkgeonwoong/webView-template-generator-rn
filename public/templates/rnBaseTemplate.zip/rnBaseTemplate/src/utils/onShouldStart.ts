import { Linking } from 'react-native';
import { isAllowedHost } from './isAllowedHost';
import { isMainFrame } from './isMainFrame';

/**
 * onShouldStartLoadWithRequest: 웹뷰가 특정 요청을 로드할지 여부를 결정합니다.
 * - true: 웹뷰에서 계속 로드
 * - false: 웹뷰 로드 중단(외부 앱/브라우저로 처리됨)
 *
 * 처리 우선순위
 * 1) Android intent 스킴
 * 2) 메인 프레임 요청 여부
 * 3) 전화/SMS/메일 스킴
 * 4) 허용 도메인 검사
 */

/* 헬퍼 함수 */
const isExternalAppScheme = (url: string) =>
  url.startsWith('tel:') || url.startsWith('sms:') || url.startsWith('mailto:');

export const makeOnShouldStart = (allowHosts: string[]) => (req: any) => {
  const url = req?.url ?? '';

  /* 1) iframe/서브리소스(css, js, img 등등)은 통과 */
  if (!isMainFrame(req)) return true;

  /* 2) 전화/SMS/메일 스킴은 외부로 연결 */
  if (isExternalAppScheme(url)) {
    Linking.openURL(url);
    return false;
  }

  /* 3) 허용되지 않은 호스트는 기기의 브라우저로 열기 */
  if (!isAllowedHost(url, allowHosts)) {
    Linking.openURL(url);
    return false;
  }

  /* 위 케이스에 해당하지 않으면 웹뷰에서 로드 */
  return true;
};
