import WebView from 'react-native-webview';
import React from 'react';

/**
 * @description 네이티브 코드에서 웹뷰로 데이터를 전송하는 역할
 * @param ref WebView 컴포넌트의 참조 객조 (null 가능)
 * @param type 전달할 이벤트 이름
 * @param event 이벤트명
 * @param data 웹뷰로 전달할 데이터
 */
export const sendToWeb = (ref: React.RefObject<WebView>, type: string, event: string, data: any) => {
  // 웹뷰에서 실행할 JavaScript 코드 문자열 생성
  const js = `
(function() {
    // 이벤트 이름은 type, 이벤트의 세부 정보는 detail에 포함
    window.dispatchEvent(new CustomEvent('${type}', { detail: ${JSON.stringify({ event, data })} }));
})(); true;`;

  // ref가 null이 아니면 해당 WebView에 위 소스 코드 주입
  ref.current?.injectJavaScript(js);
};
