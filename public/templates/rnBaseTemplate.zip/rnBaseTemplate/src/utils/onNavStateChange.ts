// 뒤로 가기 가능한지 확인할 수 있게 기록하는 함수
export const makeOnNavStateChange =
  (canGoBackRef: React.MutableRefObject<boolean>) =>
  // WebView의 상태 변경 이벤트에서 호출되는 콜백
  (s: any) => {
    // 현재 페이지에서 뒤로 가기가 가능한지 여부를 canGoBackRef에 저장
    canGoBackRef.current = s.canGoBack;
  };
