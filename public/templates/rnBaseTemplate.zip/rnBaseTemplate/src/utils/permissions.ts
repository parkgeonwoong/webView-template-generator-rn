import { Platform } from 'react-native';
import { openSettings as _openSettings, check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';

// 매게변수로 받은 scopes 문자열 배열에서 해당하는 권한을 실제 권한 객체로 맵핑함.
// ["camera"] ==> 사용중엔 기기에 따라서 PERMISSIONS.[IOS/ANDOID].CAMERA 객체리스트로 반환
const mapScopeToPermissions = (scopes: string[]): string[] => {
  const list: string[] = [];
  for (const s of scopes || []) {
    switch (s) {
      case 'camera':
        list.push(
          Platform.select({
            ios: PERMISSIONS.IOS.CAMERA,
            android: PERMISSIONS.ANDROID.CAMERA,
          })!,
        );
        break;
      case 'microphone':
        list.push(
          Platform.select({
            ios: PERMISSIONS.IOS.MICROPHONE,
            android: PERMISSIONS.ANDROID.RECORD_AUDIO,
          })!,
        );
        break;
      case 'location':
        list.push(
          Platform.select({
            ios: PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
            android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
          })!,
        );
        break;
      case 'photos':
        list.push(
          Platform.select({
            ios: PERMISSIONS.IOS.PHOTO_LIBRARY,
            android: PERMISSIONS.ANDROID.READ_MEDIA_IMAGES,
          })!,
        );
        break;
      default:
        break;
    }
  }
  // 에초에 존재하지 않는 권한이거나 권한이 없으면 null/undefined 값이라서
  // truthy 한 객체만 리턴함.
  return list.filter(Boolean);
};

// 실제 권한을 요청하는 함수
export const requestPermissions = async (scopes: string[]) => {
  const granted: string[] = []; // 허용된 권한 목록
  const denied: string[] = []; // 거부된 권한 목록
  const blocked: string[] = []; // 완전히 차단된 권한 목록 iOS 경우 한번 거부하면 설정에서 변경해야 함.

  const permissions = mapScopeToPermissions(scopes);
  for (const permission of permissions) {
    // 현재 권한 상태 확인
    let status = await check(permission as any);
    if (status === RESULTS.DENIED) {
      // DENIED 상태면 권한 요청
      status = await request(permission as any);
    }

    if (status === RESULTS.GRANTED || status === RESULTS.LIMITED) {
      // "승인"되거나 "한번만 허용"한 경우
      // 허용된 권한 목록에 추가
      granted.push(permission);
    } else if (status === RESULTS.BLOCKED) {
      // 명확히 거부한 경우
      blocked.push(permission);
    } else {
      // 그외에는 일단 권한이 없거나 확인이 안되는 경우라서 거부 목록에 넣음
      denied.push(permission);
    }
  }
  return { granted, denied, blocked };
};

// 권한을 체크하는 함수 (요청은 안함)
export const checkPermissions = async (scopes: string[]) => {
  const granted: string[] = []; // 허용된 권한 목록
  const denied: string[] = []; // 거부된 권한 목록
  const blocked: string[] = []; // 완전히 차단된 권한 목록 iOS 경우 한번 거부하면 설정에서 변경해야 함.

  const permissions = mapScopeToPermissions(scopes);
  for (const permission of permissions) {
    // 현재 권한 상태 확인
    let status = await check(permission as any);

    if (status === RESULTS.GRANTED || status === RESULTS.LIMITED) {
      // "승인"되거나 "한번만 허용"한 경우
      // 허용된 권한 목록에 추가
      granted.push(permission);
    } else if (status === RESULTS.BLOCKED) {
      // 명확히 거부한 경우
      blocked.push(permission);
    } else {
      // 그외에는 일단 권한이 없거나 확인이 안되는 경우라서 거부 목록에 넣음
      denied.push(permission);
    }
  }
  return { granted, denied, blocked };
};

// blocked의 경우 권한을 수동으로 변경할 수 있게 기기의 설정 화면을 여는 함수
export const openSettings = () => _openSettings();
