export const isAllowedHost = (url: string, allowHosts: string[]) => {
  try {
    const host = new URL(url).host;
    return allowHosts.includes(host);
  } catch {
    return false;
  }
};
