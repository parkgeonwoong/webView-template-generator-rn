// /src/components/ErrorView.tsx
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { WebErrorCategory } from '../utils/mapWebViewError';

type Props = {
  message?: string; // 원문(description) 보관용(선택)
  category?: WebErrorCategory; // 분류 결과
  onRetry: () => void; // 기본 재시도
  onOpenSettings?: () => void; // 네트워크/권한 등 설정 열기 (선택)
};

const userMessageByCategory: Record<WebErrorCategory, string> = {
  OFFLINE: '인터넷 연결이 없습니다. 연결 후 다시 시도해 주세요.',
  DNS: '도메인 이름을 찾을 수 없습니다. 주소를 확인하고 다시 시도해 주세요.',
  SSL: '보안 연결(SSL)에 문제가 있습니다. 안전한 네트워크에서 다시 시도해 주세요.',
  TIMEOUT: '서버 응답이 지연되고 있습니다. 잠시 후 다시 시도해 주세요.',
  CONNECTION_REFUSED: '서버 연결이 거부되었습니다. 서버 상태를 확인해 주세요.',
  TOO_MANY_REDIRECTS: '리다이렉션이 너무 많아 페이지를 불러올 수 없습니다.',
  UNKNOWN_URL_SCHEME: '지원되지 않는 링크 형식입니다.',
  HTTP_ERROR: '요청 처리 중 오류가 발생했습니다.',
  BAD_URL: '잘못된 주소입니다.',
  OTHER: '페이지를 불러오지 못했습니다.',
};

export const ErrorView: React.FC<Props> = ({
  message,
  category = 'OTHER',
  onRetry,
  onOpenSettings,
}) => {
  const friendly = userMessageByCategory[category];
  const showOpenSettings = category === 'OFFLINE' || category === 'SSL';

  return (
    <View style={styles.container}>
      <Text style={[styles.textBase, styles.title]}>로딩 오류</Text>
      <Text style={[styles.textBase, styles.message]}>{friendly}</Text>

      {!!message && (
        <Text style={[styles.textBase, styles.debug]} numberOfLines={3}>
          {message}
        </Text>
      )}

      <View style={styles.actions}>
        <Pressable style={styles.retryBtn} onPress={onRetry}>
          <Text style={styles.retryBtnText}>다시 시도</Text>
        </Pressable>

        {showOpenSettings && !!onOpenSettings && (
          <Pressable style={styles.settingsBtn} onPress={onOpenSettings}>
            <Text style={styles.settingsBtnText}>설정 열기</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  // 전체 컨테이너(오버레이 내부에서 화면을 가득 채움)
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    backgroundColor: 'rgba(255,255,255,1)', // 필요 시 다른 색으로 교체
  },

  // 공통 텍스트 색
  textBase: {
    color: 'rgba(255, 0, 0, 1)',
    textAlign: 'center',
  },

  title: {
    marginBottom: 8,
    fontSize: 16,
    fontWeight: '600',
  },

  message: {
    marginBottom: 16,
    fontSize: 14,
    lineHeight: 20,
  },

  // 디버깅용 원문
  debug: {
    marginBottom: 16,
    fontSize: 12,
    color: 'rgba(255, 0, 0, 1)',
  },

  // 버튼 행
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    // RN 0.71+ 에서는 gap 지원, 하위 호환이 필요하면 margin으로 간격 처리
    gap: 12,
  },

  // “다시 시도” 버튼: 흰 배경 / 검정 텍스트
  retryBtn: {
    minWidth: 112,
    paddingHorizontal: 14,
    height: 44,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 0, 0, 1)',
  },
  retryBtnText: {
    color: 'rgb(255, 255, 255)',
    fontSize: 14,
    fontWeight: '600',
  },

  // “설정 열기” 버튼: 투명 배경 / 흰색 테두리 / 흰 텍스트
  settingsBtn: {
    minWidth: 112,
    paddingHorizontal: 14,
    height: 44,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 0, 0, 1)',
    backgroundColor: 'transparent',
  },
  settingsBtnText: {
    color: 'rgba(255, 0, 0, 1)',
    fontSize: 14,
    fontWeight: '600',
  },
});
