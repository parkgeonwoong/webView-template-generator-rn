import WebView, { WebViewMessageEvent } from 'react-native-webview';
import React from 'react';
import { NavigationProp } from '@react-navigation/native';
import { Linking, Platform } from 'react-native';

import { sendToWeb } from '../utils/sendToWeb';

// __PERMISSIONS_FEATURE_START__
import { checkPermissions, openSettings, requestPermissions } from '../utils/permissions';
// __PERMISSIONS_FEATURE_END__

// __WEBVIEW_CLEAR_CACHE_FEATURE_START__
import { clearSiteData } from '../utils/clearSiteData';
// __WEBVIEW_CLEAR_CACHE_FEATURE_END__

// __APP_GET_VERSION_FEATURE_START__
import DeviceInfo from 'react-native-device-info';
// __APP_GET_VERSION_FEATURE_END__

// __MEDIA_KEYBOARD_FEATURE_START__
import { hideKeyboard, showKeyboard } from '../utils/keyboard';
// __MEDIA_KEYBOARD_FEATURE_END__

// __MEDIA_VOLUME_FEATURE_START__
import { VolumeManager } from 'react-native-volume-manager';
// __MEDIA_VOLUME_FEATURE_END__

interface MessagePayload {
  type: string;
  action: string;
  payload?: any;
}

interface HandlerParams {
  ref: React.RefObject<WebView>;
  setCacheKey: (key: any) => void;
  navigation: NavigationProp<any>;
}

/**
 * <WebView onMessage={onMessage} .../>
 * makeOnMessage: WebView ref를 받아서 onMessage 이벤트에 연결
 * WebView로부터 받은 메시지를 처리하는 엔트리 함수
 */
export const makeOnMessage =
  ({ ref, setCacheKey, navigation }: HandlerParams) =>
  async (e: WebViewMessageEvent) => {
    try {
      const msg: MessagePayload = JSON.parse(e.nativeEvent.data);
      const { type, action, payload } = msg || {};

      switch (type) {
        // __PERMISSIONS_FEATURE_START__
        case 'PERM':
          await handlePermissions(ref, action, payload);
          break;
        // __PERMISSIONS_FEATURE_END__

        // __WEBVIEW_CLEAR_CACHE_FEATURE_START__
        case 'WEBVIEW':
          await handleWebView(ref, action, setCacheKey);
          break;
        // __WEBVIEW_CLEAR_CACHE_FEATURE_END__

        // __NAV_FEATURE_WRAPPER_START__
        case 'NAV':
          handleNavigation(ref, action, navigation);
          break;
        // __NAV_FEATURE_WRAPPER_END__

        // __APP_FEATURE_WRAPPER_START__
        case 'APP':
          await handleApp(ref, action, payload);
          break;
        // __APP_FEATURE_WRAPPER_END__

        // __CALL_FEATURE_WRAPPER_START__
        case 'CALL':
          handleCall(action, payload);
          break;
        // __CALL_FEATURE_WRAPPER_END__

        // __MEDIA_FEATURE_WRAPPER_START__
        case 'MEDIA':
          await handleMedia(ref, action, payload);
          break;
        // __MEDIA_FEATURE_WRAPPER_END__
        default:
          // 아직은 PERM만 처리
          break;
      }
    } catch {
      // JSON 파싱 실패 등은 일단 무시
    }
  };

// __PERMISSIONS_FEATURE_START__
/* ==================== 권한 관련 핸들러 ==================== */
async function handlePermissions(ref: React.RefObject<WebView>, action: string, payload: any) {
  switch (action) {
    /* 권한 요청 */
    // 예: window.ReactNativeBridge.post("PERM", "REQUEST", {scopes: ['camera', 'photos']});
    case 'REQUEST': {
      const scopes: string[] = payload?.scopes || [];
      const result = await requestPermissions(scopes);
      sendToWeb(ref, 'PERM', 'RESULT', result);
      break;
    }

    /* 권한 체크 (요청은 안 하고 상태만) */
    case 'CHECK': {
      const scopes: string[] = payload?.scopes || [];
      const result = await checkPermissions(scopes);
      sendToWeb(ref, 'PERM', 'RESULT', result);
      break;
    }

    /* 권한 설정 열기 */
    case 'OPEN_SETTINGS': {
      await openSettings();
      break;
    }
  }
}
// __PERMISSIONS_FEATURE_END__

// __WEBVIEW_CLEAR_CACHE_FEATURE_START__
/* ==================== WEBVIEW 관련 핸들러 ==================== */
async function handleWebView(ref: React.RefObject<WebView>, action: string, setCacheKey: (key: any) => void) {
  switch (action) {
    /* 캐시 삭제 */
    case 'CLEAR_CACHE': {
      await clearSiteData(ref);
      setCacheKey((key: any) => key + 1);
      break;
    }
  }
}
// __WEBVIEW_CLEAR_CACHE_FEATURE_END__

// __NAV_FEATURE_WRAPPER_START__
/* ==================== 네비게이션 관련 핸들러 ==================== */
function handleNavigation(ref: React.RefObject<WebView>, action: string, navigation: NavigationProp<any>) {
  switch (action) {
    // __NAV_GO_BACK_FEATURE_START__
    /* 뒤로가기 요청 */
    case 'GO_BACK': {
      ref.current?.goBack();
      break;
    }
    // __NAV_GO_BACK_FEATURE_END__

    // __NAV_TO_TMP_FEATURE_START__
    /* 임시 페이지 이동 요청 */
    case 'TO_TMP': {
      navigation.navigate('Tmp');
      break;
    }
    // __NAV_TO_TMP_FEATURE_END__
  }
}
// __NAV_FEATURE_WRAPPER_END__

// __APP_FEATURE_WRAPPER_START__
/* ==================== APP 관련 핸들러 ==================== */
async function handleApp(ref: React.RefObject<WebView>, action: string, payload: any) {
  switch (action) {
    // __APP_OPEN_URL_FEATURE_START__
    /* 외부 앱 실행 */
    case 'OPEN_URL': {
      if (payload?.url) {
        Linking.openURL(payload.url);
      }
      break;
    }
    // __APP_OPEN_URL_FEATURE_END__

    // __APP_GET_VERSION_FEATURE_START__
    /* 앱 버전 요청 */
    case 'GET_VERSION': {
      const versionInfo = {
        'App Version': DeviceInfo.getVersion(),
        'Build Number': DeviceInfo.getBuildNumber(),
        'Bundle Id': DeviceInfo.getBundleId(),
      };
      sendToWeb(ref, 'APP', 'GET_VERSION', versionInfo);
      break;
    }
    // __APP_GET_VERSION_FEATURE_END__
  }
}
// __APP_FEATURE_WRAPPER_END__

// __CALL_FEATURE_WRAPPER_START__
/* ==================== CALL 관련 핸들러 ==================== */
function handleCall(action: string, payload: any) {
  switch (action) {
    /* 전화 요청 */
    case 'PHONE': {
      if (payload?.tel) {
        Linking.openURL(`tel:${payload.tel}`);
      }
      break;
    }
    /* 문자 요청 */
    case 'SMS': {
      if (payload?.tel) {
        const sms =
          Platform.OS === 'ios'
            ? `sms:${payload.tel}&body=${encodeURIComponent(payload.body || '')}`
            : `sms:${payload.tel}?body=${encodeURIComponent(payload.body || '')}`;
        Linking.openURL(sms);
      }
      break;
    }
    /* 이메일 요청 */
    case 'EMAIL': {
      let mail = `mailto:${payload.to}`;

      if (payload.subject) {
        mail += `?subject=${encodeURIComponent(payload.subject)}`;
      }

      if (payload.body) {
        mail += `${payload.subject ? '&' : '?'}body=${encodeURIComponent(payload.body)}`;
      }
      Linking.openURL(mail);
      break;
    }
  }
}
// __CALL_FEATURE_WRAPPER_END__

/* ==================== MEDIA 관련 핸들러 ==================== */
async function handleMedia(ref: React.RefObject<WebView>, action: string, payload: any) {
  switch (action) {
    // __MEDIA_KEYBOARD_FEATURE_START__
    /* 키보드 보여주기 */
    case 'KEYBOARD_SHOW': {
      const selector = payload?.selector;
      showKeyboard(ref, selector);
      break;
    }
    /* 키보드 감추기 */
    case 'KEYBOARD_HIDE': {
      hideKeyboard(ref);
      break;
    }
    // __MEDIA_KEYBOARD_FEATURE_END__

    // __MEDIA_VOLUME_FEATURE_START__
    /* 볼륨 변경 이벤트 감지 */
    case 'CHANGE_VOLUME': {
      try {
        const currentVolume = await VolumeManager.getVolume();
        sendToWeb(ref, 'MEDIA', 'CHANGE_VOLUME', {
          volume: currentVolume.volume,
        });

        VolumeManager.addVolumeListener(result => {
          sendToWeb(ref, 'MEDIA', 'CHANGE_VOLUME', { volume: result.volume });
        });
      } catch (err) {
        sendToWeb(ref, 'MEDIA', 'CHANGE_VOLUME_ERROR', {
          code: 'GET_VOLUME_ERROR',
          message: String(err),
        });
      }
      break;
    }
    // __MEDIA_VOLUME_FEATURE_END__
  }
}
