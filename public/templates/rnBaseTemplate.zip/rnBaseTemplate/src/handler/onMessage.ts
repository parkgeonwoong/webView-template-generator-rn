import WebView, { WebViewMessageEvent } from 'react-native-webview';
import React from 'react';
import { NavigationProp } from '@react-navigation/native';

import { sendToWeb } from '../utils/sendToWeb';

// __PERMISSIONS_FEATURE_START__
import { checkPermissions, openSettings, requestPermissions } from '../utils/permissions';
// __PERMISSIONS_FEATURE_END__

// __WEBVIEW_CLEAR_CACHE_FEATURE_START__
import { clearSiteData } from '../utils/clearSiteData';
// __WEBVIEW_CLEAR_CACHE_FEATURE_END__

interface MessagePayload {
  type: string;
  action: string;
  payload?: any;
}

interface HandlerParams {
  ref: React.RefObject<WebView>;
  setCacheKey: (key: any) => void;
  navigation: NavigationProp<any>;
}

/**
 * <WebView onMessage={onMessage} .../>
 * makeOnMessage: WebView ref를 받아서 onMessage 이벤트에 연결
 * WebView로부터 받은 메시지를 처리하는 엔트리 함수
 */
export const makeOnMessage =
  ({ ref, setCacheKey, navigation }: HandlerParams) =>
  async (e: WebViewMessageEvent) => {
    try {
      const msg: MessagePayload = JSON.parse(e.nativeEvent.data);
      const { type, action, payload } = msg || {};

      switch (type) {
        // __PERMISSIONS_FEATURE_START__
        case 'PERM':
          await handlePermissions(ref, action, payload);
          break;
        // __PERMISSIONS_FEATURE_END__

        // __WEBVIEW_CLEAR_CACHE_FEATURE_START__
        case 'WEBVIEW':
          await handleWebView(ref, action, setCacheKey);
          break;
        // __WEBVIEW_CLEAR_CACHE_FEATURE_END__

        // __NAV_FEATURE_WRAPPER_START__
        case 'NAV':
          handleNavigation(ref, action, navigation);
          break;
        // __NAV_FEATURE_WRAPPER_END__
        default:
          // 아직은 PERM만 처리
          break;
      }
    } catch {
      // JSON 파싱 실패 등은 일단 무시
    }
  };

// __PERMISSIONS_FEATURE_START__
/* ==================== 권한 관련 핸들러 ==================== */
async function handlePermissions(ref: React.RefObject<WebView>, action: string, payload: any) {
  switch (action) {
    /* 권한 요청 */
    // 예: window.ReactNativeBridge.post("PERM", "REQUEST", {scopes: ['camera', 'photos']});
    case 'REQUEST': {
      const scopes: string[] = payload?.scopes || [];
      const result = await requestPermissions(scopes);
      sendToWeb(ref, 'PERM', 'RESULT', result);
      break;
    }

    /* 권한 체크 (요청은 안 하고 상태만) */
    case 'CHECK': {
      const scopes: string[] = payload?.scopes || [];
      const result = await checkPermissions(scopes);
      sendToWeb(ref, 'PERM', 'RESULT', result);
      break;
    }

    /* 권한 설정 열기 */
    case 'OPEN_SETTINGS': {
      await openSettings();
      break;
    }
  }
}
// __PERMISSIONS_FEATURE_END__

// __WEBVIEW_CLEAR_CACHE_FEATURE_START__
/* ==================== WEBVIEW 관련 핸들러 ==================== */
async function handleWebView(ref: React.RefObject<WebView>, action: string, setCacheKey: (key: any) => void) {
  switch (action) {
    /* 캐시 삭제 */
    case 'CLEAR_CACHE': {
      await clearSiteData(ref);
      setCacheKey((key: any) => key + 1);
      break;
    }
  }
}
// __WEBVIEW_CLEAR_CACHE_FEATURE_END__

// __NAV_FEATURE_WRAPPER_START__
/* ==================== 네비게이션 관련 핸들러 ==================== */
function handleNavigation(ref: React.RefObject<WebView<{}> | null>, action: string, navigation: NavigationProp<any>) {
  switch (action) {
    // __NAV_GO_BACK_FEATURE_START__
    /* 뒤로가기 요청 */
    case 'GO_BACK': {
      ref.current?.goBack();
      break;
    }
    // __NAV_GO_BACK_FEATURE_END__

    // __NAV_TO_TMP_FEATURE_START__
    /* 임시 페이지 이동 요청 */
    case 'TO_TMP': {
      navigation.navigate('Tmp');
      break;
    }
    // __NAV_TO_TMP_FEATURE_END__
  }
}
// __NAV_FEATURE_WRAPPER_END__
