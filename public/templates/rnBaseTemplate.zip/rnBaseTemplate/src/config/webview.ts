// export const WEBVIEW_URI = 'https://www.google.com';
export const WEBVIEW_URI = '__WEBVIEW_URI__'; // 웹뷰 URL
export const WEBVIEW_DEBUGGING_ENABLED: string = '__WEBVIEW_DEBUGGING_ENABLED__'; // 웹뷰 디버깅 활성화 여부

export const USE_PERMISSION_GUIDE = '__USE_PERMISSION_GUIDE__' as unknown as boolean; // 앱 최초 실행 시 권한 안내 화면 사용 여부 (제너레이터가 true/false 로 치환)
export const PERMISSION_GUIDE_SHOWN_KEY = '__PERMISSION_GUIDE_SHOWN_KEY__'; // 앱권한안내 화면 표시 여부

/* 브릿지 코드 */
export const INJECTED_JS_BRIDGE = `
(function() {
    // 이미 브릿지가 생성되어 있다면 중복 생성 방지
    if (window.ReactNativeBridge) return;
    
    // 브릿지 객체 생성
    window.ReactNativeBridge = {
        // 네이티브로 메시지를 전송하는 함수
        post: (type, action, payload) => {
            window.ReactNativeWebView.postMessage(JSON.stringify({ type, action, payload }));
        },
        ready: true // 브릿지 준비 상태 표시
    };

    // 웹뷰가 로드되었음을 네이티브 측에 알림
    setTimeout(() => {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type:'WEBVIEW', event:'READY' }));
    },0);
})();`;

/* WebView 도메인 허용 목록 */
let WEBVIEW_HOST: string | null = null;
try {
  WEBVIEW_HOST = new URL(WEBVIEW_URI).host; // 예: "www.google.com"
} catch {
  WEBVIEW_HOST = null;
}

// ========================
// WebView 도메인 허용 목록
// ========================
// ⚠️ 템플릿 사용자가 직접 수정해야 하는 부분입니다.
// - 개발용: 사설 IP, localhost
// - 운영용: 실제 서비스 도메인들
export const ALLOW_HOSTS = [
  'localhost',
  '127.0.0.1',
  ...(WEBVIEW_HOST ? [WEBVIEW_HOST] : []),
  // __EXTRA_ALLOW_HOSTS__
  // 'www.example.com',
];
